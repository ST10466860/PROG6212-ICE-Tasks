# Student Bursary Claims Management System

A simple ASP.NET Core MVC application for submitting and managing student bursary claims.

## Features

- Submit a validated claim with student details and hours worked.
- Calculate the claim total at a fixed rate of R200 per hour.
- Search a student's claims from the previous 12 months.
- Cancel pending claims while protecting approved claims.
- Approve or reject pending claims from a basic administrator page.
- Store data using Entity Framework Core and SQL Server LocalDB.

## Run the project

1. Open `BursaryClaimsSystem.csproj` in Visual Studio 2022.
2. Restore NuGet packages.
3. Run the project. The database is created automatically on first launch.

The default SQL Server LocalDB connection is stored in `appsettings.json`.
