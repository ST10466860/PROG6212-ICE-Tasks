using BursaryClaimsSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace BursaryClaimsSystem.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Claim> Claims => Set<Claim>();
}
