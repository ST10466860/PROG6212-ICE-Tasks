using BursaryClaimsSystem.Data;
using BursaryClaimsSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BursaryClaimsSystem.Controllers;

public class ClaimsController : Controller
{
    private readonly ApplicationDbContext _context;

    public ClaimsController(ApplicationDbContext context) => _context = context;

    [HttpGet]
    public IActionResult Create() => View(new Claim());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Claim claim)
    {
        if (!ModelState.IsValid)
            return View(claim);

        claim.HourlyRate = 200.00m;
        claim.TotalClaimAmount = claim.HoursWorked * claim.HourlyRate;
        claim.DateSubmitted = DateTime.Now;
        claim.Status = "Pending";

        _context.Add(claim);
        await _context.SaveChangesAsync();
        TempData["Message"] = $"Claim #{claim.ClaimID} was submitted successfully.";
        return RedirectToAction(nameof(Index), new { studentNumber = claim.StudentNumber });
    }

    [HttpGet]
    public async Task<IActionResult> Index(string? studentNumber)
    {
        ViewBag.StudentNumber = studentNumber;
        var claims = new List<Claim>();

        if (!string.IsNullOrWhiteSpace(studentNumber))
        {
            var cutoff = DateTime.Now.AddMonths(-12);
            claims = await _context.Claims
                .Where(c => c.StudentNumber == studentNumber && c.DateSubmitted >= cutoff)
                .OrderByDescending(c => c.DateSubmitted)
                .ToListAsync();
        }

        return View(claims);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Cancel(int id)
    {
        var claim = await _context.Claims.FindAsync(id);
        if (claim == null)
            return NotFound();

        if (claim.Status != "Pending")
        {
            TempData["Error"] = "Only pending claims can be cancelled. Approved claims cannot be cancelled.";
        }
        else
        {
            claim.Status = "Cancelled";
            await _context.SaveChangesAsync();
            TempData["Message"] = $"Claim #{id} was cancelled.";
        }

        return RedirectToAction(nameof(Index), new { studentNumber = claim.StudentNumber });
    }

    [HttpGet]
    public async Task<IActionResult> Admin() =>
        View(await _context.Claims.OrderByDescending(c => c.DateSubmitted).ToListAsync());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id, string status)
    {
        var claim = await _context.Claims.FindAsync(id);
        if (claim != null && claim.Status == "Pending" && (status == "Approved" || status == "Rejected"))
        {
            claim.Status = status;
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Admin));
    }
}
