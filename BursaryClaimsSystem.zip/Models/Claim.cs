using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BursaryClaimsSystem.Models;

public class Claim
{
    [Key]
    public int ClaimID { get; set; }

    [Required, StringLength(20)]
    [Display(Name = "Student Number")]
    public string StudentNumber { get; set; } = string.Empty;

    [Required, StringLength(50)]
    [Display(Name = "First Name")]
    public string FirstName { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Surname { get; set; } = string.Empty;

    [Range(0.01, 999.99, ErrorMessage = "Hours worked must be greater than zero.")]
    [Column(TypeName = "decimal(5,2)")]
    [Display(Name = "Hours Worked")]
    public decimal HoursWorked { get; set; }

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Hourly Rate")]
    public decimal HourlyRate { get; set; } = 200.00m;

    [Column(TypeName = "decimal(10,2)")]
    [Display(Name = "Total Claim Amount")]
    public decimal TotalClaimAmount { get; set; }

    [Display(Name = "Date Submitted")]
    public DateTime DateSubmitted { get; set; } = DateTime.Now;

    [Required, StringLength(20)]
    public string Status { get; set; } = "Pending";
}
